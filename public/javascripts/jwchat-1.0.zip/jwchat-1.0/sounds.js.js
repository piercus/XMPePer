var SOUNDS = new Object();

SOUNDS['message_recv'] = "./sounds/message_recv.swf"
SOUNDS['message_queue'] = "./sounds/message_queue.swf"
SOUNDS['chat_recv'] = "./sounds/chat_recv.swf"
SOUNDS['chat_queue'] = "./sounds/chat_queue.swf"
SOUNDS['online'] = "./sounds/online.swf"
SOUNDS['offline'] = "./sounds/offline.swf"
SOUNDS['startup'] = "./sounds/startup.swf"
SOUNDS['connected'] = "./sounds/connected.swf"
